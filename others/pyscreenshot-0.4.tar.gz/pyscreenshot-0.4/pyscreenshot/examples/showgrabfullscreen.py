import pyscreenshot as ImageGrab

if __name__ == "__main__":
    # fullscreen
    im=ImageGrab.grab()
    im.show()

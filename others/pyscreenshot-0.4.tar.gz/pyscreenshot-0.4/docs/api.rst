API
===

.. automodule:: pyscreenshot
    :members:
    :undoc-members:


VERSION = (1, 4, 4)

default_app_config = 'image.apps.ImageConfig'